/** Automatically generated file. DO NOT MODIFY */
package hk.patsolution.apps.snapcard;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}