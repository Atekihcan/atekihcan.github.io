package hk.patsolution.apps.leapmotion;

import hk.patsolution.apps.snapcard.R;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;

import com.google.gson.Gson;

public class LeapMotionActivity extends Activity {
	private static final String TAG = LeapMotionActivity.class.getSimpleName();
	private HandPositionView view;
	private Gson gson;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		getWindow().requestFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_leap_motion);
		view = (HandPositionView) findViewById(R.id.hand_position_view);
		gson = new Gson();
	}

	protected void onResume() {
		super.onResume();
		connectToServer();
	}

	private void connectToServer() {
		(new RetrieveLeapMotionDataTask()).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
	}

	private class RetrieveLeapMotionDataTask extends
			AsyncTask<Void, String, Void> {
		protected Void doInBackground(Void... args) {
			try {
				URL url = new URL(getString(R.string.leap_endpoint));
				   HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
				Log.i(TAG,"connected");
				InputStream in = urlConnection.getInputStream();
				int length=0;
				byte data[]=new byte[1000];
				String buffer="",temp;
				while((length=in.read(data))!=-1){
					
//					Log.i(TAG,"length of data got="+length);

					buffer=buffer.concat(new String(data,0,length));
					int end=buffer.lastIndexOf("}");
					if(end>-1){
						temp=buffer.substring(0,end+1);
						int start=temp.lastIndexOf("{");
						if(start>-1){
							this.onProgressUpdate(buffer.substring(start,end+1));
						}
						buffer=buffer.substring(end);
					}
				}
				
				Log.i(TAG,"end of loop");
			} catch (Exception e) {
				e.printStackTrace();
			}
			return null;
		}
		
		protected void onProgressUpdate(String... args){
			Log.i(TAG,"got last message="+args[0]);
			view.setPosition(gson.fromJson(args[0],Hand.class));
			view.postInvalidate();
		}
	}
	
}
