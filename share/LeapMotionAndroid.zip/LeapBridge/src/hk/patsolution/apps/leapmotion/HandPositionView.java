package hk.patsolution.apps.leapmotion;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;

public class HandPositionView extends View {
	private static final String TAG=HandPositionView.class.getSimpleName();
	private Hand position;
	private Paint paint;
	public Hand getPosition() {
		return position;
	}

	public void setPosition(Hand position) {
		this.position = position;
	}

	public HandPositionView(Context context, AttributeSet attrs) {
		super(context, attrs);
		position=new Hand();
		paint=new Paint();
		paint.setColor(Color.RED);
		paint.setStrokeWidth(1);
		paint.setStyle(Style.FILL);
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		Log.i(TAG,"onDraw called");
		if(position.isPresent()){
			int width=this.getWidth()/2;
			int height=this.getHeight()/2;
			float x=width+position.getX()*width/100;
			float z=height+position.getZ()*width/100;
			float y=position.getY();
			canvas.drawCircle(x, z, y, paint);
		}

	}
}
