Leap-Motion-Call-Controller
===========================

Simple demo of muting an Android phone with a Leap Motion and on{X}.

If you make something wildly wizard-like with this, please do let me know! I'm on Twitter at @thatpatrickguy, or you can find me at http://www.patrickcatanzariti.com.

Best of luck,

PatCat
